import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { X, ArrowDownToLine, ArrowUpFromLine, Loader2 } from "lucide-react";

function formatKsh(cents: number) {
  return Math.floor(cents / 100).toLocaleString("en-KE");
}

interface WalletModalProps {
  open: boolean;
  onClose: () => void;
}

type Tab = "deposit" | "withdraw" | "history";

export function WalletModal({ open, onClose }: WalletModalProps) {
  const [tab, setTab] = useState<Tab>("deposit");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [amount, setAmount] = useState<string>("");
  const [phone, setPhone] = useState<string>("");

  const { data: wallet, refetch: refetchWallet } = useQuery({
    queryKey: [api.wallet.summary.path],
    queryFn: async () => {
      const res = await fetch(api.wallet.summary.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to load wallet");
      return res.json();
    },
    enabled: open,
    refetchInterval: open ? 5000 : false,
  });

  const { data: txs = [], refetch: refetchTxs } = useQuery({
    queryKey: [api.wallet.transactions.path],
    queryFn: async () => {
      const res = await fetch(api.wallet.transactions.path, {
        credentials: "include",
      });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: open && tab === "history",
  });

  const depositMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.wallet.deposit.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          amount: parseInt(amount, 10),
          phone: phone || undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || "Deposit failed");
      return data;
    },
    onSuccess: (data: any) => {
      toast({
        title: "Check your phone",
        description:
          data.message ||
          "An M-Pesa STK push has been sent — enter your PIN to confirm.",
      });
      setAmount("");
      refetchWallet();
      queryClient.invalidateQueries({ queryKey: [api.wallet.transactions.path] });
    },
    onError: (err: Error) => {
      toast({
        title: "Deposit failed",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.wallet.withdraw.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          amount: parseInt(amount, 10),
          phone: phone || undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || "Withdrawal failed");
      return data;
    },
    onSuccess: (data: any) => {
      toast({
        title: "Withdrawal requested",
        description: data.message || "You'll receive M-Pesa shortly.",
      });
      setAmount("");
      refetchWallet();
      queryClient.invalidateQueries({ queryKey: [api.wallet.transactions.path] });
    },
    onError: (err: Error) => {
      toast({
        title: "Withdrawal failed",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  if (!open) return null;

  const presets = tab === "deposit" ? [50, 100, 500, 1000, 5000] : [100, 500, 1000, 5000, 20000];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-card border border-white/10 rounded-3xl p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-black text-glow">Wallet</h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats */}
        {wallet && (
          <div className="grid grid-cols-2 gap-2 mb-5 text-xs">
            <div className="bg-background/50 p-3 rounded-xl border border-white/5">
              <div className="text-muted-foreground">Balance</div>
              <div className="text-lg font-bold text-success">
                {formatKsh(wallet.totalBalance)} KSH
              </div>
            </div>
            <div className="bg-background/50 p-3 rounded-xl border border-white/5">
              <div className="text-muted-foreground">Deposited</div>
              <div className="text-lg font-bold">
                {formatKsh(wallet.totalDeposited)} KSH
              </div>
            </div>
            <div className="bg-background/50 p-3 rounded-xl border border-white/5">
              <div className="text-muted-foreground">Wagered</div>
              <div className="text-lg font-bold">
                {formatKsh(wallet.totalWagered)} KSH
              </div>
            </div>
            <div className="bg-background/50 p-3 rounded-xl border border-white/5">
              <div className="text-muted-foreground">Withdrawn</div>
              <div className="text-lg font-bold">
                {formatKsh(wallet.totalWithdrawn)} KSH
              </div>
            </div>
            {!wallet.wageringMet && wallet.wageringRemaining > 0 && (
              <div className="col-span-2 bg-yellow-500/10 border border-yellow-500/30 p-3 rounded-xl">
                <div className="text-yellow-400 font-semibold text-xs">
                  Wager {formatKsh(wallet.wageringRemaining)} KSH more to unlock
                  withdrawals
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-4 bg-background/50 p-1 rounded-xl">
          {(["deposit", "withdraw", "history"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold uppercase tracking-wide transition-all ${
                tab === t
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "deposit" && (
          <div className="space-y-3">
            <div>
              <Label className="text-xs uppercase">Amount (KES)</Label>
              <Input
                type="number"
                inputMode="numeric"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="100"
                className="bg-background/60 h-12 text-lg font-mono"
              />
              <div className="flex gap-1 mt-2 flex-wrap">
                {presets.map((p) => (
                  <button
                    key={p}
                    onClick={() => setAmount(String(p))}
                    className="text-xs px-3 py-1 rounded bg-muted hover:bg-muted/80"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs uppercase">M-Pesa Phone (optional)</Label>
              <Input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Defaults to your account number"
                className="bg-background/60 h-11"
              />
            </div>
            <Button
              onClick={() => depositMutation.mutate()}
              disabled={!amount || depositMutation.isPending}
              className="w-full h-12 bg-success hover:bg-success/90 text-success-foreground font-bold uppercase tracking-wide"
            >
              {depositMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <ArrowDownToLine className="w-4 h-4 mr-2" />
                  Send STK Push
                </>
              )}
            </Button>
          </div>
        )}

        {tab === "withdraw" && (
          <div className="space-y-3">
            {wallet?.withdrawBlockedReason && (
              <div className="bg-yellow-500/10 border border-yellow-500/30 p-3 rounded-xl text-xs text-yellow-300">
                {wallet.withdrawBlockedReason}
              </div>
            )}
            <div>
              <Label className="text-xs uppercase">Amount (KES)</Label>
              <Input
                type="number"
                inputMode="numeric"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="500"
                className="bg-background/60 h-12 text-lg font-mono"
              />
              <div className="flex gap-1 mt-2 flex-wrap">
                {presets.map((p) => (
                  <button
                    key={p}
                    onClick={() => setAmount(String(p))}
                    className="text-xs px-3 py-1 rounded bg-muted hover:bg-muted/80"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs uppercase">Send to (M-Pesa)</Label>
              <Input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Defaults to your account number"
                className="bg-background/60 h-11"
              />
            </div>
            {wallet && (
              <div className="text-[11px] text-muted-foreground space-y-1">
                <div>
                  Daily remaining: {formatKsh(wallet.dailyRemaining)} /{" "}
                  {formatKsh(wallet.dailyLimit)} KSH
                </div>
                <div>Min withdrawal: {formatKsh(wallet.minWithdrawal)} KSH</div>
              </div>
            )}
            <Button
              onClick={() => withdrawMutation.mutate()}
              disabled={
                !amount ||
                withdrawMutation.isPending ||
                (wallet && !wallet.canWithdraw)
              }
              className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-bold uppercase tracking-wide"
            >
              {withdrawMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <ArrowUpFromLine className="w-4 h-4 mr-2" />
                  Withdraw
                </>
              )}
            </Button>
          </div>
        )}

        {tab === "history" && (
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {txs.length === 0 && (
              <div className="text-center text-muted-foreground text-sm py-8">
                No transactions yet
              </div>
            )}
            {txs.map((tx: any) => (
              <div
                key={tx.id}
                className="bg-background/50 p-3 rounded-xl border border-white/5 flex items-center justify-between"
              >
                <div>
                  <div className="text-xs uppercase font-bold flex items-center gap-2">
                    {tx.type === "deposit" ? (
                      <ArrowDownToLine className="w-3 h-3 text-success" />
                    ) : (
                      <ArrowUpFromLine className="w-3 h-3 text-primary" />
                    )}
                    {tx.type}
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    {new Date(tx.createdAt).toLocaleString("en-KE")}
                  </div>
                  {tx.failureReason && (
                    <div className="text-[10px] text-destructive">
                      {tx.failureReason}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold">
                    {formatKsh(tx.amount)} KSH
                  </div>
                  <div
                    className={`text-[10px] uppercase font-bold ${
                      tx.status === "success"
                        ? "text-success"
                        : tx.status === "failed"
                          ? "text-destructive"
                          : "text-yellow-400"
                    }`}
                  >
                    {tx.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
